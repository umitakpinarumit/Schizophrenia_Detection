import pandas as pd
from scipy.signal import butter,lfilter
from os import listdir

def butter_bandpass(lowcut, highcut, fs, order=4):
    nyq = 0.5 * fs
    low = lowcut / nyq
    high = highcut / nyq
    b, a = butter(order, [low, high], btype='band')
    return b, a

labels=["0","1"]

for label in labels:
    directory = f"C:/Users/aslan/Desktop/Sizofreni_Detection/DATA/csv_raw_data/{label}"
    channels=['Fp2','F8','T4','T6','O2','Fp1','F7','T3','T5','O1','F4','C4','P4','F3','C3','P3','Fz','Cz','Pz']
    
    b, a = butter_bandpass(0.5, 45.0, 128.0, 2)
    #d, c = butter_lowpass_filter(45.0, 128.0, 2)
    #f, e = butter_highpass_filter(0.5, 128.0, 2)
    
    trials = listdir(directory)
    
    for trial in trials:
        print(trial)
        path_csv_raw_dr = f"{directory}/{trial}"
        path_csv_raw_data = pd.read_csv(path_csv_raw_dr, usecols=[*range(1, 20)])
        
        file_name = f"C:/Users/aslan/Desktop/Sizofreni_Detection/DATA/csv_data/{label}/{trial}"
        filtered_dataset = pd.DataFrame(columns=['Fp2','F8','T4','T6','O2','Fp1','F7','T3','T5','O1','F4','C4','P4','F3','C3','P3','Fz','Cz','Pz'])
        print(path_csv_raw_data)
        for i in channels:
            print(f"------Band_Pass_Filter : {i}")
            temp = lfilter(b, a, path_csv_raw_data[i])
            temp1=["{:0.10f}".format(x) for x in temp]
            filtered_dataset[i] = temp1
        filtered_dataset.to_csv(file_name, index=False,)
