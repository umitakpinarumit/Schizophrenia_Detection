import mne
from os import listdir


labels=["0","1"]

for label in labels:
    directory_ctn=f'C:/Users/aslan/Desktop/Sizofreni_Detection/DATA/edf_raw_data/{label}'
    directory_csv=f'C:/Users/aslan/Desktop/Sizofreni_Detection/DATA/csv_raw_data/{label}'
    
    trials = listdir(directory_ctn)
    
    for trial in trials:
        
        filename=trial.split(".")[0]
        
        eeg_raw = mne.io.read_raw_edf(f"{directory_ctn}/{trial}")
        eeg_raw.resample(128, npad='auto')
        df=eeg_raw.to_data_frame()
        print(df.shape)
        df.to_csv(f'{directory_csv}/{filename}.csv',index=False)